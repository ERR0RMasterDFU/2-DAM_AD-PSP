package com.salesianostriana.dam.ejercicio_asociaciones_03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioAsociaciones03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
