package com.salesianostriana.dam.ejercicio_asociaciones_03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioAsociaciones03Application {

    public static void main(String[] args) {
        SpringApplication.run(EjercicioAsociaciones03Application.class, args);
    }

}
