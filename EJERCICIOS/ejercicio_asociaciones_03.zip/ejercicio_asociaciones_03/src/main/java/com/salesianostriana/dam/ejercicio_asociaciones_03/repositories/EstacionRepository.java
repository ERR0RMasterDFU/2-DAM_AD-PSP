package com.salesianostriana.dam.ejercicio_asociaciones_03.repositories;

import com.salesianostriana.dam.ejercicio_asociaciones_03.models.Estacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstacionRepository extends JpaRepository<Estacion, Long> {
}
