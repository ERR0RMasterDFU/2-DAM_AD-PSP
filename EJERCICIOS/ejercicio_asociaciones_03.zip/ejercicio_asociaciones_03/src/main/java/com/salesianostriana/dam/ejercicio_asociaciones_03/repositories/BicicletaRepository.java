package com.salesianostriana.dam.ejercicio_asociaciones_03.repositories;

import com.salesianostriana.dam.ejercicio_asociaciones_03.models.Bicicleta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BicicletaRepository extends JpaRepository<Bicicleta, Long> {
}
